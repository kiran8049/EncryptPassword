/**
 * 
 */
package com.tcs.controller;

import java.io.File;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.tcs.Validator.FileUploadValidator;
import com.tcs.Validator.WordValidator;
import com.tcs.vo.CommonVo;
import com.tcs.xml.XMLCrud;

/**
 * @author 496387
 *
 */
@Controller
@PropertySource("classpath:config.properties")
public class DictonaryController {
	@Autowired
	XMLCrud xmlCrud;
	
	@Autowired
	WordValidator wordValidator;
	
	@Autowired
	FileUploadValidator fileValidator;
	
	@Autowired
	private Environment env;

	
	@RequestMapping(value = "upload.htm", method = RequestMethod.GET)
	public String uploadPage( HttpSession session,@ModelAttribute CommonVo commonVo,ModelMap model) {
		// HttpSession session = ((HttpServletRequest) request).getSession(false);
		//System.out.println("xmlPath1 "+env.getProperty("xmlPath"));\
		if(session.getAttribute("dictonaryFlag")==null)
			 session.setAttribute("dictonaryFlag", "N");
		else{
			String dictonaryFlag = (String)session.getAttribute("dictonaryFlag");
			if(dictonaryFlag.equalsIgnoreCase("Y"))
			return "menu";
		}
		return "upload";

	}
	@RequestMapping(value = "upload.htm", method = RequestMethod.POST)
	public ModelAndView fileSubmit(HttpSession session,HttpServletResponse response, HttpServletRequest request ,@ModelAttribute CommonVo commonVo, BindingResult result,ModelMap model) {
		//HttpSession session = ((HttpServletRequest) request).getSession(false); 
		if (result.hasErrors()) {
            System.out.println("validation errors");
            return new ModelAndView("upload");
        }
		else{
			String dictonaryFlag = (String)session.getAttribute("dictonaryFlag");
			if(dictonaryFlag.equalsIgnoreCase("N"))
			{
				try {
					File xmlFile = multipartToFile(commonVo.getDictonaryFile());
					File xsdFile = getFile("xsd/dictonary.xsd");
					if(xsdFile!=null){
					boolean isValid = xmlCrud.validateXMLSchema(xmlFile, xsdFile);
					if(isValid)
					{
						session.setAttribute("dictonaryFlag", "Y");
						return new ModelAndView("menu",model);
					}
					else
					{
						System.out.println("not valid XML");
						model.addAttribute("invalid", "Y");
					}
					}
				} catch (IllegalStateException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		//model.addAttribute("message", "Spring 3 MVC Hello World");
		return new ModelAndView("upload",model);
		}

	}

	@RequestMapping(value = "menu.htm", method = RequestMethod.GET)
	public String menuPage( HttpSession session,@ModelAttribute CommonVo commonVo,ModelMap model) {
		if(session.getAttribute("dictonaryFlag")==null){
		 session.setAttribute("dictonaryFlag", "N");
		 return "upload";
	}
		return "menu";
	}

	@RequestMapping(value = "search.htm", method = RequestMethod.GET)
	public String searchPage( HttpSession session,@ModelAttribute CommonVo commonVo,ModelMap model) {
		if(session.getAttribute("dictonaryFlag")==null){
			 session.setAttribute("dictonaryFlag", "N");
			 return "upload";
		}
		return "search";

	}
	@RequestMapping(value = "search.htm", method = RequestMethod.POST)
	public ModelAndView searchWord(HttpSession session,HttpServletResponse response, HttpServletRequest request ,@ModelAttribute CommonVo commonVo,ModelMap model) {
		Document doc = readXml();
		String meaning = xmlCrud.SearchDictonaryEntry(doc, commonVo.getSearchTerm());
		if(meaning==null)
			commonVo.setMeaning("Word not in dictionary");
		else
			commonVo.setMeaning(meaning);
		return new ModelAndView("search",model);
	}
	
	@RequestMapping(value = "add.htm", method = RequestMethod.GET)
	public String addPage( HttpSession session,@ModelAttribute CommonVo commonVo,ModelMap model) {
		if(session.getAttribute("dictonaryFlag")==null){
		 session.setAttribute("dictonaryFlag", "N");
		 return "upload";
	}
		return "add";

	}
	@RequestMapping(value = "add.htm", method = RequestMethod.POST)
	public ModelAndView addWord(HttpSession session,HttpServletResponse response, HttpServletRequest request ,@ModelAttribute CommonVo commonVo,BindingResult result,ModelMap model) {
		wordValidator.validate(commonVo, result);
		if (result.hasErrors()) {
            System.out.println("validation errors");
            model.addAttribute("meaning", commonVo.getMeaning());
            model.addAttribute("searchTerm", commonVo.getSearchTerm());
            model.addAttribute("message", "Enter Alphabetic Word");
            return new ModelAndView("add");
        }
		else
		{
			Document doc = readXml();
			String meaning = xmlCrud.SearchDictonaryEntry(doc, commonVo.getSearchTerm());
			if(meaning==null || commonVo.getOverwite().equalsIgnoreCase("Y")){
				xmlCrud.AddDictonaryEntry(doc, commonVo.getSearchTerm(), commonVo.getMeaning());
				model.addAttribute("addedAlert", "Word added successfully.");
				return new ModelAndView("menu",model);
			}
			else{
				commonVo.setOverwite("N");
				model.addAttribute("meaning", commonVo.getMeaning());
	            model.addAttribute("searchTerm", commonVo.getSearchTerm());
	            model.addAttribute("overwiteAlert", commonVo.getOverwite());
				return new ModelAndView("add",model);
			}
		}
		
		
	}
	
	@RequestMapping(value = "exit.htm")
	public String exit(HttpSession session,@ModelAttribute CommonVo commonVo,ModelMap model) {
		if(session.getAttribute("dictonaryFlag")!=null){
		session.removeAttribute("dictonaryFlag");
		}
		return "upload";
	}
	public Document readXml(){
		File file = new File(env.getProperty("xmlPath")+File.separator+"dictonary.xml");
		 DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
         factory.setNamespaceAware(false);
         Document doc=null;
         try {
			DocumentBuilder builder = factory.newDocumentBuilder();
			doc = builder.parse(file);
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return doc;
	}
	public File multipartToFile(MultipartFile multipart) throws IllegalStateException, IOException 
	{
	        File convFile = new File( multipart.getOriginalFilename());
	        //multipart.transferTo(convFile);
	        File file = new File(env.getProperty("xmlPath")+File.separator+"dictonary.xml");

	        if (!file.exists()) {
	            file.createNewFile();
	        }
	        multipart.transferTo(file);
	        return convFile;
	}
	
	private File getFile(String fileName) {
		File rFile=null;
		StringBuilder result = new StringBuilder("");
		Resource resource = new ClassPathResource(fileName);
		try {
			rFile= resource.getFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rFile;
	}
}
