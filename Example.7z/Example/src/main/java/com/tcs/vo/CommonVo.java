/**
 * 
 */
package com.tcs.vo;

import org.springframework.web.multipart.MultipartFile;

/**
 * @author 496387
 *
 */
public class CommonVo {

	MultipartFile dictonaryFile;
	String message;
	String searchTerm;
	String meaning;
	String overwite;

	public MultipartFile getDictonaryFile() {
		return dictonaryFile;
	}

	public void setDictonaryFile(MultipartFile dictonaryFile) {
		this.dictonaryFile = dictonaryFile;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getSearchTerm() {
		return searchTerm;
	}

	public void setSearchTerm(String searchTerm) {
		this.searchTerm = searchTerm;
	}

	public String getMeaning() {
		return meaning;
	}

	public void setMeaning(String meaning) {
		this.meaning = meaning;
	}

	public String getOverwite() {
		return overwite;
	}

	public void setOverwite(String overwite) {
		this.overwite = overwite;
	}
	
}
