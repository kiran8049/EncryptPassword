package com.tcs.Validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.tcs.vo.CommonVo;

@Component
public class WordValidator implements Validator {

	private static final String ALPHABETIC_PATTERN= "[a-zA-Z]+";
	private Pattern pattern;
	 private Matcher matcher;
	public boolean supports(Class arg0) {
        return CommonVo.class.isAssignableFrom(arg0);
	}

	public void validate(Object arg0, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "searchTerm", "error.searchTerm", "Word is required.");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "meaning", "error.meaning", "Meaning is required.");
        CommonVo commonVo = (CommonVo)arg0;
        if (commonVo.getSearchTerm() != null && commonVo.getSearchTerm()!="") {
        	   pattern = Pattern.compile(ALPHABETIC_PATTERN);
        	   matcher = pattern.matcher(commonVo.getSearchTerm());
        	   if (!matcher.matches()) {
        	    errors.rejectValue("searchTerm", "error.searchTerm",
        	      "Enter Alphabetic Word");
        	   }
        }
	
	}

}
