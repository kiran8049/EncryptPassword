/**
 * 
 */
package com.tcs.vo;

import org.springframework.web.multipart.MultipartFile;

/**
 * @author 496387
 *
 */
public class CommonVo {

	MultipartFile dictonaryFile;

	public MultipartFile getDictonaryFile() {
		return dictonaryFile;
	}

	public void setDictonaryFile(MultipartFile dictonaryFile) {
		this.dictonaryFile = dictonaryFile;
	}
	
}
