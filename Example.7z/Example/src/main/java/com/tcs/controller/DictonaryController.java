/**
 * 
 */
package com.tcs.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.tcs.vo.CommonVo;

/**
 * @author 496387
 *
 */
@Controller
public class DictonaryController {
	@RequestMapping(value = "upload.htm", method = RequestMethod.GET)
	public String uploadPage(HttpServletRequest request,HttpServletResponse response,@ModelAttribute CommonVo commonVo,ModelMap model) {
		 HttpSession session = ((HttpServletRequest) request).getSession(false); 
		 if (session==null) {
			 session = ((HttpServletRequest) request).getSession(true);
			 session.setAttribute("dictonaryFlag", "N");
		 }
		return "upload";

	}
	@RequestMapping(value = "upload.htm", method = RequestMethod.POST)
	public String fileSubmit(HttpServletRequest request,HttpServletResponse response,@ModelAttribute CommonVo commonVo,ModelMap model) {
		HttpSession session = ((HttpServletRequest) request).getSession(false); 
		if (session!=null) {
			String dictonaryFlag = (String)session.getAttribute("dictonaryFlag");
			if(dictonaryFlag.equalsIgnoreCase("N"))
			{
				
			}
		}
		//model.addAttribute("message", "Spring 3 MVC Hello World");
		return "upload";

	}

	@RequestMapping(value = "/hello/{name:.+}", method = RequestMethod.GET)
	public ModelAndView hello(@PathVariable("name") String name) {

		ModelAndView model = new ModelAndView();
		model.setViewName("hello");
		model.addObject("msg", name);

		return model;

	}
}
