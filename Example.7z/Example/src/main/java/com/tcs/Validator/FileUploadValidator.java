/**
 * 
 */
package com.tcs.Validator;

import org.apache.commons.fileupload.FileUpload;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.tcs.vo.CommonVo;

/**
 * @author 496387
 *
 */
@Component
public class FileUploadValidator implements Validator{

	public boolean supports(Class arg0) {
		return FileUpload.class.isAssignableFrom(arg0);
	}

	public void validate(Object arg0, Errors arg1) {
		CommonVo file = (CommonVo)arg0;

		if(file.getDictonaryFile().getSize()==0){
			arg1.rejectValue("dictonaryFile", "Please Select a file");
		}
	}

	
}
