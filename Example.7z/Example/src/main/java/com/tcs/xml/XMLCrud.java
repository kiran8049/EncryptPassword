/**
 * 
 */
package com.tcs.xml;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * @author 496387
 *
 */
@Component
public class XMLCrud {
	
	public static void main(String[] args) {
        new XMLCrud();
    }
	@Autowired
	private Environment env;
	
public void AddDictonaryEntry(Document doc,String word,String meaning){
	String existingMeaning = SearchDictonaryEntry(doc,word);
	if(existingMeaning==null){
	Element child = addElement(doc, "entry");
    addAttribute(doc,child,"word",word);
    addAttribute(doc,child,"meaning",meaning);
    
	}
	else{
		OverrideDictonaryEntry(doc,word,meaning);
	}
	File file = new File(env.getProperty("xmlPath")+File.separator+"dictonary.xml");
    try {
		save(doc,file);
	} catch (TransformerConfigurationException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (TransformerException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

public String SearchDictonaryEntry(Document doc,String sword) {
	String meaning=null;
	 XPathFactory xPathfactory = XPathFactory.newInstance();
	 XPath xpath = xPathfactory.newXPath();
	 XPathExpression expr;
	try {
		expr = xpath.compile("//dictionary/entry[@word]");
		NodeList nl = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
	
		 for (int i = 0; i < nl.getLength(); i++)
		 {
		     Node currentItem = nl.item(i);
		     String word = currentItem.getAttributes().getNamedItem("word").getNodeValue();
		     if(sword.equalsIgnoreCase(word)){
		    	 meaning = currentItem.getAttributes().getNamedItem("meaning").getNodeValue();
		    	 break;
		     }
		 }
	} catch (XPathExpressionException e) {
		e.printStackTrace();
	}
	return meaning;
	
}
public boolean OverrideDictonaryEntry(Document doc,String sword,String meaning) {
		
	/* DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
	 DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	 DocumentBuilder builder = factory.newDocumentBuilder();
	 Document doc = builder.parse("uri to xmlfile");*/
	 XPathFactory xPathfactory = XPathFactory.newInstance();
	 XPath xpath = xPathfactory.newXPath();
	 XPathExpression expr;
	try {
		expr = xpath.compile("//dictionary/entry[@word]");
		NodeList nl = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
	
		 for (int i = 0; i < nl.getLength(); i++)
		 {
		     Node currentItem = nl.item(i);
		     String word = currentItem.getAttributes().getNamedItem("word").getNodeValue();
		     //System.out.println("word "+word);
		     if(sword.equalsIgnoreCase(word)){
		    	 currentItem.getAttributes().getNamedItem("meaning").setNodeValue(meaning);
		    	 return true;
		     }
		 }
		// System.out.println("meaning "+meaning);
	} catch (XPathExpressionException e) {
		e.printStackTrace();
	}
	return false;
	
}
public boolean readXML(File xmlFilePath,File xsdFilePath){
	
	if(validateXMLSchema(xmlFilePath,xsdFilePath))
	{
		return true;
	}
	else
		return false;
}
public static boolean validateXMLSchema( File xmlPath,File xsdPath){
    
    try {
        SchemaFactory factory = 
                SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = factory.newSchema(xsdPath);
        Validator validator = schema.newValidator();
        validator.validate(new StreamSource(xmlPath));
    } catch (SAXException e) {
        System.out.println("Exception: "+e.getMessage());
        return false;
    }
    catch (IOException e){
    	System.out.println("Exception: "+e.getMessage());
    }
    return true;
}
private File getFile(String fileName) {

	StringBuilder result = new StringBuilder("");

	//Get file from resources folder
	ClassLoader classLoader = getClass().getClassLoader();
	File file = new File(classLoader.getResource(fileName).getFile());
	return file;
	/*try {
		Scanner scanner = new Scanner(file);
		while (scanner.hasNextLine()) {
			String line = scanner.nextLine();
			result.append(line).append("\n");
		}

		scanner.close();

	} catch (IOException e) {
		e.printStackTrace();
	}*/
}
   
    private DocumentBuilder builder;

    public Node getRootNode(Document xmlDoc) {

        Node nRoot = null;

        if (xmlDoc != null) {

            nRoot = xmlDoc.getDocumentElement();

        }

        return nRoot;

    }

    public Document createNewDocument() throws ParserConfigurationException {

        Document doc = getDocumentBuilder().newDocument();
        Element root = doc.createElement("root");
        doc.adoptNode(root);
        doc.appendChild(root);

        return doc;

    }

    public Element setRootNode(Document xmlDoc, String name) {

        removeNode(getRootNode(xmlDoc));
        Element root = xmlDoc.createElement(name);
        xmlDoc.adoptNode(root);
        xmlDoc.appendChild(root);

        return root;


    }

    public Document loadDocument(InputStream is) throws ParserConfigurationException, SAXException, IOException {

        return getDocumentBuilder().parse(is);

    }

    public Document loadDocument(File file) throws ParserConfigurationException, SAXException, IOException {

        return getDocumentBuilder().parse(file);

    }

    public Document loadDocumentFromString(String xml) throws ParserConfigurationException, SAXException, IOException {

        Document doc = null;

        ByteArrayInputStream bais = null;

        //StringReader sr = null;
        //InputSource is = null;
        try {

            bais = new ByteArrayInputStream(xml.getBytes());

            doc = loadDocument(bais);

        } finally {

//            try { sr.close(); } catch (Exception e) { }
            try {
                bais.close();
            } catch (Exception e) {
            }

        }

        return doc;

    }

    protected DocumentBuilder getDocumentBuilder() throws ParserConfigurationException {

        if (builder == null) {

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(false); // You might want to change this...
            builder = factory.newDocumentBuilder();

        }

        return builder;

    }

    public Element addElement(Document xmlDoc, String name) {

        Element child = xmlDoc.createElement(name);
        getRootNode(xmlDoc).appendChild(child);

        return child;

    }
	public Element addAttribute(Document xmlDoc, Element  ele, String name,String value) {
		Attr genAttribute = xmlDoc.createAttribute(name);
		genAttribute.setValue(value);
		ele.setAttributeNode(genAttribute);
        return ele;

    }

    public Node addElement(Document xmlDoc, Node node, String name) {

        Node child = xmlDoc.createElement(name);
        node.appendChild(child);

        return child;

    }

    public Node addElement(Document xmlDoc, Node node, String name, String text) {

        Node child = addElement(xmlDoc, node, name);
        child.setTextContent(text);

        return child;

    }

    public void removeNode(Node parentNode) {

        if (parentNode != null) {

            while (parentNode.hasChildNodes()) {

                removeNode(parentNode.getFirstChild());

            }

            Node parent = parentNode.getParentNode();
            if (parent != null) {

                parent.removeChild(parentNode);

                NodeList childNodes = parent.getChildNodes();
                if (childNodes.getLength() > 0) {

                    List<Node> lstTextNodes = new ArrayList<Node>(childNodes.getLength());
                    for (int index = 0; index < childNodes.getLength(); index++) {

                        Node childNode = childNodes.item(index);
                        if (childNode.getNodeType() == Node.TEXT_NODE) {

                            lstTextNodes.add(childNode);

                        }

                    }

                    for (Node node : lstTextNodes) {

                        removeNode(node);

                    }

                }

            }

        }

    }

    public void save(Document xmlDoc, File fFile) throws TransformerConfigurationException, TransformerException, IOException {

        FileOutputStream fos = null;

        try {

            fos = new FileOutputStream(fFile);
            save(xmlDoc, fos);

            fos.flush();

        } finally {

            try {
                fos.close();
            } catch (Exception e) {
            }

        }

    }

    public void save(Document xmlDoc, OutputStream os) throws TransformerConfigurationException, TransformerException, IOException {

        OutputStreamWriter osw = null;

        try {

            osw = new OutputStreamWriter(os);
            save(xmlDoc, osw);
            osw.flush();

        } finally {

            try {
                osw.close();
            } catch (Exception exp) {
            }

        }

    }


    public String save(Document xmlDoc) throws TransformerConfigurationException, IOException, TransformerException {

        String sValue = null;

        ByteArrayOutputStream baos = null;

        try {

            baos = new ByteArrayOutputStream();
            save(xmlDoc, baos);
            baos.flush();
            sValue = new String(baos.toByteArray());

        } finally {

            try {
                baos.close();
            } catch (Exception exp) {
            }

        }

        return sValue;

    }

    public void save(Document xmlDoc, Writer os) throws TransformerConfigurationException, TransformerException {

        Transformer tf = TransformerFactory.newInstance().newTransformer();
        tf.setOutputProperty(OutputKeys.INDENT, "yes");
        tf.setOutputProperty(OutputKeys.METHOD, "xml");
        tf.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");

        DOMSource domSource = new DOMSource(xmlDoc);
        StreamResult sr = new StreamResult(os);
        tf.transform(domSource, sr);

    }
	public Document readXml(){
		File file = new File(env.getProperty("xmlPath")+File.separator+"dictonary.xml");
		 DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
         factory.setNamespaceAware(false);
         Document doc=null;
         try {
			DocumentBuilder builder = factory.newDocumentBuilder();
			doc = builder.parse(file);
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return doc;
	}
}
